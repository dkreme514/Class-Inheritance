// *****************************************************************
// * Class Name:  square.h                                         *
// * Description:  Header file for the square class                *
// * Date:  03/02/2023  (Date of function modification)            *
// * Author:   Donald Kremer (Name of Function Author.             *
// *****************************************************************
#include <iostream>
#ifndef SQUARE_H
#define SQUARE_H
#include <iomanip>
#include <cmath>
#include "shape.h"

class Square: public Shape {
public:
    Square();
    Square(const double s);
    double getSide();
    void setSide(const double s) ;
    void PrintData();
private:
    double side;
};


#endif
