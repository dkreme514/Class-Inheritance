// *****************************************************************
// * Class Name:  rectangle.h                                      *
// * Description:  Header file for the rectangle class             *
// * Date:  03/03/2023  (Date of function modification)            *
// * Author:  Donald Kremer  (Name of Function Author.)            *
// * References:  Dr. David Gaitros                                *
// *****************************************************************

#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <iostream>
#include <iomanip>
#include "shape.h"
using namespace std;

class Rectangle: public Shape
        {
public:
    Rectangle();
    Rectangle(const double l, const double w);
    double getLength();
    double getWidth();


    void setWidth(const double w);
    void setLength(const double l);

    void PrintData();
private:
    double length;
    double width;
};
#endif
