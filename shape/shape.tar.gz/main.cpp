// *****************************************************************
// * Class Name:  main.cpp                                         *
// * Description: Main driver for the shape.h and shape.cpp class  *
// * Date:  03/02/2023  (Date of function modification)            *
// * Author:   Donald Kremer    (Name of Function Author.          *
// * References:  Dr. David A. Gaitros                             *
// *****************************************************************
#include <iostream>
#include "shape.h"
#include "square.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"

using namespace std;
int main() {
    cout << "Hello, World!" << endl;
    Shape MyShape1;

    Square MySquare1(15);
    Square MySquare2;

    Rectangle MyRec1(25,30);
    Rectangle MyRec2;
    Circle MyCircle1(5);
    Circle MyCircle2;
    Triangle MyTry(5,3,7);
    Triangle MyTry2;

    MySquare2.PrintData();
    MyRec2.PrintData();
    MyCircle2.PrintData();
    MyTry2.PrintData();

    MySquare1.PrintData();
    MyRec1.PrintData();
    MyCircle1.PrintData();
    MyTry.PrintData();

    return 0;
}
