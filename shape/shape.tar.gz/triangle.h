// *****************************************************************
// * Class Name:  triangle.h                                       *
// * Description:  Header file for the triangle class              *
// * Date:  03/02/2023  (Date of function modification)            *
// * Author:  Donald Kremer   (Name of Function Author.            *
// *****************************************************************
#ifndef TRIANGLE_H
#define TRIANGLE_H
#include "shape.h"
#include <iostream>

class Triangle: public Shape {
public:
    Triangle();
    Triangle(const double s1, const double s2, const double s3);
    double getSide1();
    double getSide2();
    double getSide3();

    void PrintData();
    void setSide1(const double s1);
    void setSide2(const double s2);
    void setSide3(const double s3);

private:
    double side1;
    double side2;
    double side3;
};


#endif 
