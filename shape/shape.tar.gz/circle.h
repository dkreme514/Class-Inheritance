// *****************************************************************
// * Class Name:  circle.h                                         *
// * Description:  Header file for the circle class                *
// * Date:  03/02/2023  (Date of function modification)            *
// * Author:   Donald Kremer    (Name of Function Author.          *
// * References: Dr. David A. Gaitros                              *
// *****************************************************************
#ifndef CIRCLE_H
#define CIRCLE_H
#include "shape.h"
#include <iostream>
using namespace std;


class Circle: public Shape {
public:
    Circle();
    Circle(const double r);
    void setRadius(const double r);
    void PrintData();
    double getRadius();
private:
    double radius;
};


#endif
