// *****************************************************************
// * Class Name:  shape.h                                          *
// * Description:  Header file for the base class                  *
// * Date:  03/02/2023 (Date of function modification)             *
// * Author:   Donald Kremer (Name of Function Author.             *
// * References:  Dr. David Gaitros                                *
// *****************************************************************
#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

#ifndef SHAPE_H
#define SHAPE_H
class Shape
{
public:
   Shape();
   Shape(const double a, const double p=1);
   void PrintData();
   void setArea(const double a);
   void setPerimeter(const double p);
   double getArea();
   double getPerimeter();
protected:
   double area;
   double perimeter;


};
#endif
