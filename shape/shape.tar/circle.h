#include <iostream>
#ifndef CIRCLE_H
#define CIRCLE_H
#include "shape.h"

using namespace std;


class Circle: public Shape {
public:
    Circle();
    Circle(const double r);

    void setArea(const double a);
    void setPerimeter(const double p);
    void setRadius(const double r);
    void PrintData();
    double getArea();
    double getPerimeter();
    double getRadius();


private:
    double radius;

};


#endif
