
#include "rectangle.h"

Rectangle::Rectangle()
{
    length=1;
    width=1;
    setArea(length,width);
    setPerimeter(length,width);
}
Rectangle::Rectangle(const double l, const double w):length(l), width(w)
{
    setArea(length,width);
    setPerimeter(length ,width);
}
double Rectangle::getLength()
{
    return length;
}
double Rectangle::getWidth()
{
    return width;
}
double Rectangle::getArea()
{
    return area;
}
double Rectangle::getPerimeter(){
    return perimeter;
}
void Rectangle::setWidth(const double w)
{
    width=w;
}
void Rectangle::setLength(const double l)
{
    length=l;
}
void Rectangle::setArea(const double l, const double w)
{
    area=(length*width);
}

void Rectangle::setPerimeter(const double l, const double w)
{
    perimeter = ((2*length)+(2*width));
}

void Rectangle::PrintData()
{
    cout << "The length of side 1 is : " << length << endl;
    cout << "The length of side 2 is : " << width << endl;
    cout << "The area of the rectangle is : " << area << endl;
    cout << "The perimeter of the rectangle is : " << perimeter << endl;
}

