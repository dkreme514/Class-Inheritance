#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
#include "square.h"

Square::Square()
{
    side = 1.00;
    area = side*side;
}
Square::Square(const double s)
{
    side =s;
    setArea(side);
    setPerimeter(side);
    cout<< "The length of the side is : " << side<< endl;
    cout<< "The area of the square is : " <<  area<< endl;
    cout<< "The perimeter of the square is : " <<perimeter<< endl;
}

double Square::getSide()
{
    return side;
}
double Square::getArea()
{
    return area;
}
double Square::getPerimeter() {return perimeter;}
void Square::setSide(const double s) {side=s;}
void Square::setArea(const double a) { area=side+side;}
void Square::setPerimeter(const double p) {perimeter=4*side;}
void Square::PrintData()
{
    cout << "The length of the side is : " << side << endl;
    cout << "The area of the square is : " << area << endl;
    cout << "The perimeter of the square is : " << perimeter << endl;
}


