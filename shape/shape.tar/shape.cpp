#include "shape.h"
#include <iomanip>
using namespace std;

Shape::Shape()
{
    area=1;
    perimeter=1;
}
Shape::Shape(const double a, const double p):area(a),perimeter(p)
{

}

double Shape::getArea()
{
    return area;
}
void Shape::setArea(const double a)
{
    area=a;
}
void Shape::setPerimeter(const double p)
{
    perimeter=p;
}
double Shape::getPerimeter()
{
    return perimeter;
}
void Shape::PrintData()
{
    cout<< "Invalid, please retry for another shape."<<endl;
}
