#include <iostream>
#ifndef SQUARE_H
#define SQUARE_H
#include <iomanip>
#include <cmath>
#include "shape.h"

class Square: public Shape {
public:
    Square();
    Square(const double s);
    double getSide();
    double getArea();
    double getPerimeter();
    void setSide(const double s) ;
    void setArea(const double a) ;
    void setPerimeter(const double s);
    void PrintData();
private:
    double side;
 //   double area;
  //  double perimeter;

};


#endif
