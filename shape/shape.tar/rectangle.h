#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <iostream>
#include <iomanip>
#include "shape.h"
using namespace std;

class Rectangle: public Shape
        {
public:
    Rectangle();
    Rectangle(const double l, const double w);
    double getLength();
    double getWidth();
    double getArea();
    double getPerimeter();

    void setWidth(const double w);
    void setLength(const double l);
    void setArea(const double l, const double w) ;
    void setPerimeter(const double l, const double w);

    void PrintData();
private:
    double length;
    double width;
};
#endif
