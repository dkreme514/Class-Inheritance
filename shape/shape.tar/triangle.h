#ifndef TRIANGLE_H
#define TRIANGLE_H
#include "shape.h"
#include <iostream>

class Triangle: public Shape {
public:
    Triangle();
    Triangle(const double s1, const double s2, const double s3);
    double getSide1();
    double getSide2();
    double getSide3();
    double getArea();
    double getPerimeter();

    void PrintData();
    void setSide1(const double s1);
    void setSide2(const double s2);
    void setSide3(const double s3);
    void setPerimeter(const double p);
    void setArea(const double s1, const double s2, const double s3);
private:
    double side1;
    double side2;
    double side3;
};


#endif 
