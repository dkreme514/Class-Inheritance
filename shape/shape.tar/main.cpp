#include <iostream>
#include "shape.h"
#include "square.h"
#include "rectangle.h"
#include "circle.h"
#include "triangle.h"

using namespace std;
int main()
 {
    cout << "Hello, World!" << endl;
    Shape MyShape1;

    Square MySquare1(15);
    Rectangle MyRec1(25,43);
    Circle MyCircle1(5);
    Triangle MyTry(5,3,7);

    MySquare1.PrintData();
    MyRec1.PrintData();
    MyCircle1.PrintData();
    MyTry.PrintData();

    return 0;
}

