#include <iostream>
#include <cmath>
#include <iomanip>
#include "circle.h"
using namespace std;

Circle::Circle()
{
    radius=1;
}
Circle::Circle(const double r):radius(r)
{
    setArea(r);
    setPerimeter(r);
}
double Circle::getArea()
{
    return area;
}
double Circle::getPerimeter()
{
    return perimeter;
}
double Circle::getRadius()
{
    return radius;
}
void Circle::setArea(const double a)
{
    area=(3.14*(2*radius));
}
void Circle::setPerimeter(const double p)
{
    perimeter=(3.14*radius*radius);
}
void Circle::setRadius(const double r)
{
    radius=r;
}
void Circle::PrintData()
{
    cout<<"The radius of the circle is : "<< radius << endl;
    cout<<"The area of the circle is : "<<area << endl;
    cout<<"The perimeter of the circle is : "<< perimeter<< endl;

}


