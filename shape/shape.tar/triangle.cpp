#include <iostream>
#include "triangle.h"
#include "math.h"
#include <cmath>
using namespace std;
Triangle::Triangle()
{
    side1=1;
    side2=1;
    side3=1;

}
Triangle::Triangle(const double s1, const double s2, const double s3): side1(s1), side2(s2), side3(s3)
{
    setArea(s1,s2,s3);

}
double Triangle::getSide1() {return side1;}
double Triangle::getSide2(){return side2;}
double Triangle::getSide3() {return side3;}
double Triangle::getArea()
{
    return area;
}
void Triangle::setSide1(const double s1) {side1=s1;}
void Triangle::setSide2(const double s2) {side2=s2;}
void Triangle::setSide3(const double s3){side3=s3;}
void Triangle::setArea(const double s1, const double s2, const double s3)
{
    double s=(side1+side2+side3)/2;
    area=sqrt(s*(s-side1)*(s-side2)*(s-side3));
}
void Triangle::PrintData()
{
    cout << "The length of side 1 is : " << side1 << endl;
    cout << "The length of side 2 is : " << side2 << endl;
    cout << "The length of side 3 is : " << side3 << endl;
    cout << "The area of the triangle is : " << area << endl;

}

