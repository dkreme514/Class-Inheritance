#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

#ifndef SHAPE_H
#define SHAPE_H
class Shape
{
public:
   Shape();
   Shape(const double a, const double p=1);
   void PrintData();
   void setArea(const double s);
   void setPerimeter(const double s);
   double getArea();
   double getPerimeter();
protected:
   double area;
   double perimeter;


};
#endif
